#' A data set of T cell contigs as a list outputed from the 
#' filter_contig_annotation files.
#' @docType data
#' @name contig_list
#' 
NULL
