#' A seurat object of 1000 single T cells derived
#' from 3 clear cell renal carcinoma patients.
#' @name screp_example
#' @docType data
#'
#'
NULL
